﻿`                                                     `Blockchain, Cryptocurrency and Web3

INTRODUCTION 

![](Aspose.Words.fcd1ecd7-0c5c-49c1-a4cf-f032fc7b61c5.001.jpeg)

Let dive in and learn about blockchain, cryptocurrency and Web3.Digital currency, the first decentralize cryptocurrency was bitcon.But what is Web3 about ? It is next Generation of internet.
If we have keen observation we can see that those all emerging technology have essence of A.I. 

1) Getting started with blockchain technology:

   ![](Aspose.Words.fcd1ecd7-0c5c-49c1-a4cf-f032fc7b61c5.002.jpeg)
   This is the platform where digital currency, cryptocurrency and Bitcons are built on.This is complementary field. It has potential to

   revolutionalize the way we work. This records the transaction and make it difficult for hacker to steal the information. Some very

   important key feature : Trust, Security and transparency. Lets see uses of blockchain : Healthcare, voting, cryptocurrency.

1) The future of NFTs and and digital ownership:

   Non-Fungible tokens this represent ownership of particular asset.

   This NFTs are very unique and specified that they can’t be copied.

   NFTs represent different genera be it art, media, digital content, 

   music, film, script. Digital ownership has evolved with blockchain and Web3.

   What is Web3?

   This incorporate various concepts. Web is repetition of process of 

   Utterance and set of values and application. Also know as Web 3.0, Decentralized Web or Semantic Web.

1) Exploring Decentralize Autonomous Organization and How to 

   Decentralize Application.

   They are virtual organization that operate on blockchain technology which allows decision making and governance for

   Decentralization.

   ![](Aspose.Words.fcd1ecd7-0c5c-49c1-a4cf-f032fc7b61c5.003.jpeg)

   This distribute the functionality across multiple nodes or computer on a network rather than relying on single central server. Key component of decentralization : 

`          `Peer-to-peer (P2P)                                     

`          `Distributed File System

`          `General Mechanism           







